
package com.dulceria.dao;

import com.dulceria.dao.Conexion;
import com.dulceria.model.Venta;
import java.sql.*;
import java.util.ArrayList;

public class VentaDAO {

    public boolean registrarVenta(Venta v) {
        String sql = "INSERT INTO venta (id_cliente, id_empleado, fecha, total) VALUES (?,?,?,?)";
        try (Connection con = Conexion.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            
            ps.setInt(1, v.getIdCliente());
            ps.setInt(2, v.getIdEmpleado());
            ps.setString(3, v.getFecha());
            ps.setDouble(4, v.getTotal());
            
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al registrar venta: " + e.getMessage());
            return false;
        }
    }

    public ArrayList<com.dulceria.model.Venta> listarVentas() {
    ArrayList<com.dulceria.model.Venta> lista = new ArrayList<>();
    String sql = "SELECT * FROM venta";
    try (Connection con = Conexion.getConnection();
         PreparedStatement ps = con.prepareStatement(sql);
         ResultSet rs = ps.executeQuery()) {
        while (rs.next()) {
            com.dulceria.model.Venta v = new com.dulceria.model.Venta();
            v.setIdVenta(rs.getInt("id_venta"));
            v.setIdCliente(rs.getInt("id_cliente"));
            v.setIdEmpleado(rs.getInt("id_empleado"));
            v.setFecha(rs.getString("fecha")); // Se extrae como String
            v.setTotal(rs.getDouble("total")); // Se extrae como Double
            lista.add(v);
        }
    } catch (Exception e) {
        System.err.println("Error al listar ventas: " + e.getMessage());
    }
    return lista;
}
    public boolean editar(com.dulceria.model.Venta v) {
    String sql = "UPDATE venta SET id_cliente=?, id_empleado=?, fecha=?, total=? WHERE id_venta=?";
    try (Connection con = Conexion.getConnection();
         PreparedStatement ps = con.prepareStatement(sql)) {
        ps.setInt(1, v.getIdCliente());
        ps.setInt(2, v.getIdEmpleado());
        ps.setString(3, v.getFecha());
        ps.setDouble(4, v.getTotal());
        ps.setInt(5, v.getIdVenta());
        return ps.executeUpdate() > 0;
    } catch (SQLException e) {
        System.err.println("Error al editar venta: " + e.getMessage());
        return false;
    }
    }

// Método para Eliminar
    public boolean eliminar(int idVenta) {
        String sql = "DELETE FROM venta WHERE id_venta = ?";
        try (Connection con = Conexion.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, idVenta);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al eliminar venta: " + e.getMessage());
            return false;
        }
    }
}
