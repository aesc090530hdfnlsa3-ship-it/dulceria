/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.dulceria.dao;

import com.dulceria.model.Empleado;
import java.sql.*;
import java.util.ArrayList;

public class EmpleadoDAO {

    public boolean insertar(Empleado e) {
        String sql = "INSERT INTO empleado (nombre, puesto) VALUES (?, ?)";
        try (Connection con = Conexion.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, e.getNombre());
            ps.setString(2, e.getPuesto());
            return ps.executeUpdate() > 0;
        } catch (SQLException ex) {
            System.err.println("Error al insertar empleado: " + ex.getMessage());
            return false;
        }
    }

    public ArrayList<com.dulceria.model.Empleado> listarEmpleados() {
    ArrayList<com.dulceria.model.Empleado> lista = new ArrayList<>();
    String sql = "SELECT * FROM empleado";
    try (Connection con = Conexion.getConnection();
         PreparedStatement ps = con.prepareStatement(sql);
         ResultSet rs = ps.executeQuery()) {
        while (rs.next()) {
            com.dulceria.model.Empleado e = new com.dulceria.model.Empleado();
            e.setIdEmpleado(rs.getInt("id_empleado"));
            e.setNombre(rs.getString("nombre"));
            e.setPuesto(rs.getString("puesto"));
            lista.add(e);
        }
    } catch (Exception e) {
        System.err.println("Error al listar empleados: " + e.getMessage());
    }
    return lista;
}

    public boolean editar(Empleado e) {
        String sql = "UPDATE empleado SET nombre=?, puesto=? WHERE id_empleado=?";
        try (Connection con = Conexion.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, e.getNombre());
            ps.setString(2, e.getPuesto());
            ps.setInt(3, e.getIdEmpleado());
            return ps.executeUpdate() > 0;
        } catch (SQLException ex) {
            System.err.println("Error al editar empleado: " + ex.getMessage());
            return false;
        }
    }

    public boolean eliminar(int id) {
        String sql = "DELETE FROM empleados WHERE id_empleado=?";
        try (Connection con = Conexion.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException ex) {
            System.err.println("Error al eliminar empleado: " + ex.getMessage());
            return false;
        }
    }
}