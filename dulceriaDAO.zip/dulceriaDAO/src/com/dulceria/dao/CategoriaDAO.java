
package com.dulceria.dao;

import com.dulceria.dao.Conexion;
import com.dulceria.model.Categoria;
import java.sql.*;
import java.util.ArrayList;

public class CategoriaDAO {

    public boolean insertar(Categoria c) {
        String sql = "INSERT INTO categoria (nombre) VALUES (?)";
        try (Connection con = Conexion.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, c.getNombre());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al insertar categoría: " + e.getMessage());
            return false;
        }
    }

    public ArrayList<com.dulceria.model.Categoria> listarCategorias() {
    ArrayList<com.dulceria.model.Categoria> lista = new ArrayList<>();
    String sql = "SELECT * FROM categoria";
    try (Connection con = Conexion.getConnection();
         PreparedStatement ps = con.prepareStatement(sql);
         ResultSet rs = ps.executeQuery()) {
        while (rs.next()) {
            com.dulceria.model.Categoria c = new com.dulceria.model.Categoria();
            c.setIdCategoria(rs.getInt("id_categoria"));
            c.setNombre(rs.getString("nombre"));
            lista.add(c);
        }
    } catch (Exception e) {
        System.err.println("Error al listar categorías: " + e.getMessage());
    }
    return lista;
}

    public boolean editar(Categoria c) {
        String sql = "UPDATE categoria SET nombre=? WHERE id_categoria=?";
        try (Connection con = Conexion.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, c.getNombre());
            ps.setInt(2, c.getIdCategoria());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al editar: " + e.getMessage());
            return false;
        }
    }

    public boolean eliminar(int id) {
        String sql = "DELETE FROM categoria WHERE id_categoria=?";
        try (Connection con = Conexion.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al eliminar: " + e.getMessage());
            return false;
        }
    }
}