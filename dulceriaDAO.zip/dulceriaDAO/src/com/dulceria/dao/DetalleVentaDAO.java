/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.dulceria.dao;

import com.dulceria.model.DetalleVenta;
import java.sql.*;
import java.util.ArrayList;

public class DetalleVentaDAO {

    public boolean insertar(DetalleVenta d) {
        String sql = "INSERT INTO detalle (id_producto, id_venta, cantidad) VALUES (?, ?, ?)";
        try (Connection con = Conexion.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            
            ps.setInt(1, d.getIdProducto());
            ps.setInt(2, d.getIdVenta());
            ps.setInt(3, d.getCantidad());
            
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al insertar detalle de venta: " + e.getMessage());
            return false;
        }
    }

    public ArrayList<com.dulceria.model.DetalleVenta> listarDetalles() {
    ArrayList<com.dulceria.model.DetalleVenta> lista = new ArrayList<>();
    String sql = "SELECT * FROM detalle";
    try (Connection con = Conexion.getConnection();
         PreparedStatement ps = con.prepareStatement(sql);
         ResultSet rs = ps.executeQuery()) {
        while (rs.next()) {
            com.dulceria.model.DetalleVenta d = new com.dulceria.model.DetalleVenta();
            d.setIdProducto(rs.getInt("id_producto"));
            d.setIdVenta(rs.getInt("id_venta"));
            d.setCantidad(rs.getInt("cantidad"));
            lista.add(d);
        }
    } catch (Exception e) {
        System.err.println("Error al listar detalles: " + e.getMessage());
    }
    return lista;
}

    public boolean editar(com.dulceria.model.DetalleVenta d, int idProdAntiguo, int idVentaAntigua) {
    // 1. Usamos el nombre real de tu tabla de MariaDB: 'detalle'
    String sql = "UPDATE detalle SET id_producto=?, id_venta=?, cantidad=? WHERE id_producto=? AND id_venta=?";
    
    try (Connection con = Conexion.getConnection();
         PreparedStatement ps = con.prepareStatement(sql)) {
         
        // 2. Parámetros NUEVOS en orden consecutivo (1, 2, 3)
        ps.setInt(1, d.getIdProducto());
        ps.setInt(2, d.getIdVenta());
        ps.setInt(3, d.getCantidad());
        
        // 3. Parámetros ANTIGUOS para el WHERE (4, 5) para identificar la fila original
        ps.setInt(4, idProdAntiguo);
        ps.setInt(5, idVentaAntigua);
        
        return ps.executeUpdate() > 0;
    } catch (SQLException e) {
        System.err.println("Error al editar detalle: " + e.getMessage());
        return false;
    }
}

    public boolean eliminar(int idProducto, int idVenta) {
        String sql = "DELETE FROM detalle WHERE id_producto=? AND id_venta=?";
        try (Connection con = Conexion.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            
            ps.setInt(1, idProducto);
            ps.setInt(2, idVenta);
            
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al eliminar detalle: " + e.getMessage());
            return false;
        }
    }
}