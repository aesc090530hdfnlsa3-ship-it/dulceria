
package com.dulceria.model;

public class Producto {
    private int idProducto;
    private int idCategoria; // Nuevo campo FK
    private String nombre;
    private double precio;    // Nuevo campo

    public Producto() {}

    // Constructor para nuevos registros (sin ID)
    public Producto(int idCategoria, String nombre, double precio, int stock) {
        this.idCategoria = idCategoria;
        this.nombre = nombre;
        this.precio = precio;
    }

    // Getters y Setters
    public int getIdProducto() { return idProducto; }
    public void setIdProducto(int id) { this.idProducto = id; }

    public int getIdCategoria() { return idCategoria; }
    public void setIdCategoria(int idCategoria) { this.idCategoria = idCategoria; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public double getPrecio() { return precio; }
    public void setPrecio(double precio) { this.precio = precio; }
}