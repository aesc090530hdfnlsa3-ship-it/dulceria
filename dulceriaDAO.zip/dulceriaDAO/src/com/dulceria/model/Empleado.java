
package com.dulceria.model;

public class Empleado {
    private int idEmpleado;
    private String nombre;
    private String puesto;

    // Constructor vacío
    public Empleado() {}

    // Constructor con parámetros (para nuevos registros)
    public Empleado(String nombre, String puesto) {
        this.nombre = nombre;
        this.puesto = puesto;
    }

    // Getters y Setters
    public int getIdEmpleado() { return idEmpleado; }
    public void setIdEmpleado(int id) { this.idEmpleado = id; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public String getPuesto() { return puesto; }
    public void setPuesto(String puesto) { this.puesto = puesto; }
}