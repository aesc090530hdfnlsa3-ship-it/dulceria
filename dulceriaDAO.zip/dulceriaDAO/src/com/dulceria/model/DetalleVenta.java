/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.dulceria.model;

public class DetalleVenta {
    private int idProducto; // Definido como Varchar en tu libreta
    private int idVenta;
    private int cantidad;      // Definido como INT en tu libreta

    // Constructor vacío
    public DetalleVenta() {}

    // Constructor con parámetros
    public DetalleVenta(int idProducto, int idVenta, int cantidad, int subtotal) {
        this.idProducto = idProducto;
        this.idVenta = idVenta;
        this.cantidad = cantidad;
    }

    // Getters y Setters
    public int getIdProducto() { return idProducto; }
    public void setIdProducto(int idProducto) { this.idProducto = idProducto; }

    public int getIdVenta() { return idVenta; }
    public void setIdVenta(int idVenta) { this.idVenta = idVenta; }

    public int getCantidad() { return cantidad; }
    public void setCantidad(int cantidad) { this.cantidad = cantidad; }
}