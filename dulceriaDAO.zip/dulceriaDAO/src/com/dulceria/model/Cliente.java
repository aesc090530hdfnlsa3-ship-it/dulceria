
package com.dulceria.model;

public class Cliente {
    private int idCliente;
    private String nombre;
    private String telefono; // Cambiado a String para soportar los 10 dígitos del teléfono

    // Constructor vacío
    public Cliente() {}

    // Constructor con parámetros para nuevos registros
    public Cliente(String nombre, String telefono) {
        this.nombre = nombre;
        this.telefono = telefono;
    }

    // Getters y Setters
    public int getIdCliente() { return idCliente; }
    public void setIdCliente(int idCliente) { this.idCliente = idCliente; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public String getTelefono() { return telefono; }
    public void setTelefono(String telefono) { this.telefono = telefono; }
}