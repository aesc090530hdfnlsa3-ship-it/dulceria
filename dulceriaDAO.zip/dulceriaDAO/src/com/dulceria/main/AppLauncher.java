/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.dulceria.main;


import com.dulceria.view.FrmMenuPrincipal;
public class AppLauncher {
    public static void main(String[] args) {
    FrmMenuPrincipal menu = new FrmMenuPrincipal();
    menu.setExtendedState(FrmMenuPrincipal.MAXIMIZED_BOTH);
    menu.setTitle("Dulceria v1.0 - Panel de Administración");
    menu.setVisible(true);
}
}
